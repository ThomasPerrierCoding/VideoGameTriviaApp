package edu.ranken.thomasperrier.videogametriviaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Question4Activity extends AppCompatActivity {

    Button buttonSubmit;
    int score;
    String scoreTxt;
    RadioButton radioButtonCorrect;
    RadioButton radioButtonWrong1;
    RadioButton radioButtonWrong2;
    RadioGroup radioGroup2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question4);

        radioButtonCorrect = findViewById(R.id.radioButtonCorrect);
        buttonSubmit = findViewById(R.id.buttonSubmit3);
        radioButtonWrong1 = findViewById(R.id.radioButtonWrong1);
        radioButtonWrong2 = findViewById(R.id.radioButtonWrong2);
        radioGroup2 = findViewById(R.id.radioGroup2);

        Intent intent = getIntent();
        scoreTxt = intent.getStringExtra("SCORE").toString();

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score = Integer.valueOf(scoreTxt);
                if(radioButtonCorrect.isChecked()){
                    score += 1000;
                }
                scoreTxt = String.valueOf(score);
                Intent intent = new Intent(Question4Activity.this,Question5Activity.class);
                intent.putExtra("SCORE",scoreTxt);

                startActivity(intent);
                finish();
            }
        });
    }
}
