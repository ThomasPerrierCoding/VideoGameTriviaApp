package edu.ranken.thomasperrier.videogametriviaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

public class Question5Activity extends AppCompatActivity {

    Button buttonSubmit;
    EditText editTextPac;
    int score;
    String scoreTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question5);

        buttonSubmit = findViewById(R.id.buttonSubmit4);
        editTextPac = findViewById(R.id.editTextPac);

        Intent intent = getIntent();
        scoreTxt = intent.getStringExtra("SCORE").toString();

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score = Integer.valueOf(scoreTxt);
                if(editTextPac.getText().toString().equals("")){
                    Toast toast = Toast.makeText(getApplicationContext(),"NO INPUT DETECTED. PLEASE ENTER AN ANSWER",Toast.LENGTH_LONG);
                    toast.show();
                    editTextPac.requestFocus();
                }
                else if(editTextPac.getText().toString().equals("3333360")){
                    score +=1000;

                    scoreTxt = String.valueOf(score);

                    Intent intent = new Intent(Question5Activity.this,Question6Activity.class);
                    intent.putExtra("SCORE",scoreTxt);

                    startActivity(intent);
                    finish();
                }
                else{
                    scoreTxt = String.valueOf(score);

                    Intent intent = new Intent(Question5Activity.this,Question6Activity.class);
                    intent.putExtra("SCORE",scoreTxt);

                    startActivity(intent);
                    finish();
                }

            }
        });

    }
}
