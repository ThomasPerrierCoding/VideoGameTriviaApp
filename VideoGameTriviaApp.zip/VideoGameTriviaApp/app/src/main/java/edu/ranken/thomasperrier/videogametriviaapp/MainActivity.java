package edu.ranken.thomasperrier.videogametriviaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imageViewBanner;
    Button buttonStart;
    //Button buttonScore;
    Button buttonExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonStart = (Button) findViewById(R.id.buttonStart);
        //buttonScore = (Button) findViewById(R.id.buttonScore);
        buttonExit = (Button) findViewById(R.id.buttonExit);
        imageViewBanner = findViewById(R.id.imageViewBanner);

        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Question1Activity.class);

                startActivity(intent);
            }
        });
    }
}
