package edu.ranken.thomasperrier.videogametriviaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

public class ScoreActivity extends AppCompatActivity {

    final String NONGAMERRANK = "NON-GAMER";
    final String NOOBRANK = "NOOB";
    final String CASUALRANK = "CASUAL GAMER";
    final String GAMERRANK = "GAMER";
    final String TRUERANK = "TRUE GAMER";
    final String EPICRANK = "EPIC GAMER";
    final String PRORANK = "PRO GAMER";

    final String NONGAMERQ = "You got 0/6 questions right!";
    final String NOOBQ = "You got 1/6 questions right!";
    final String CASUALQ = "You got 2/6 questions right!";
    final String GAMERQ = "You got 3/6 questions right!";
    final String TRUEQ = "You got 4/6 questions right!";
    final String EPICQ = "You got 5/6 questions right!";
    final String PROQ = "You got 6/6 questions right!";

    final String NONGAMERP = "You scored a total of 0 points!";
    final String NOOBP = "You scored a total of 1000 points!";
    final String CASUALP = "You scored a total of 2000 points!";
    final String GAMERP = "You scored a total of 3000 points!";
    final String TRUEP = "You scored a total of 4000 points!";
    final String EPICP = "You scored a total of 5000 points!";
    final String PROP = "You scored a total of 6000 points!";

    ImageView imageViewResult;
    TextView textViewPoints;
    TextView textViewScore;
    TextView textViewRank;
    int score;
    String scoreTxt;
    Button buttonReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        textViewScore = findViewById(R.id.textViewScore);
        textViewPoints = findViewById(R.id.textViewPoints);
        textViewRank = findViewById(R.id.textViewRank);
        imageViewResult = findViewById(R.id.imageViewResult);
        buttonReturn = findViewById(R.id.buttonReturn);

        Intent intent = getIntent();
        scoreTxt = intent.getStringExtra("SCORE");
        score = Integer.valueOf(scoreTxt);

        if(score == 0){
            imageViewResult.setImageResource(R.drawable.gameover);
            textViewRank.setText(NONGAMERRANK);
            textViewScore.setText(NONGAMERQ);
            textViewPoints.setText(NONGAMERP);
        }
        else if(score == 1000){
            imageViewResult.setImageResource(R.drawable.noob);
            textViewRank.setText(NOOBRANK);
            textViewScore.setText(NOOBQ);
            textViewPoints.setText(NOOBP);
        }
        else if(score == 2000){
            imageViewResult.setImageResource(R.drawable.casual);
            textViewRank.setText(CASUALRANK);
            textViewScore.setText(CASUALQ);
            textViewPoints.setText(CASUALP);
        }
        else if(score == 3000){
            imageViewResult.setImageResource(R.drawable.gamer);
            textViewRank.setText(GAMERRANK);
            textViewScore.setText(GAMERQ);
            textViewPoints.setText(GAMERP);
        }
        else if(score == 4000){
            imageViewResult.setImageResource(R.drawable.truegamer);
            textViewRank.setText(TRUERANK);
            textViewScore.setText(TRUEQ);
            textViewPoints.setText(TRUEP);
        }
        else if(score == 5000){
            imageViewResult.setImageResource(R.drawable.epic);
            textViewRank.setText(EPICRANK);
            textViewScore.setText(EPICQ);
            textViewPoints.setText(EPICP);
        }
        else{
            imageViewResult.setImageResource(R.drawable.pro);
            textViewRank.setText(PRORANK);
            textViewScore.setText(PROQ);
            textViewPoints.setText(PROP);
        }

        buttonReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
