package edu.ranken.thomasperrier.videogametriviaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;


public class Question1Activity extends AppCompatActivity {

    Button buttonSubmit;
    EditText editTextGuess1;
    int score = 0;
    String scoreTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question1);

        editTextGuess1 = findViewById(R.id.editTextGuess1);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(editTextGuess1.getText().toString().equals(""))
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"NO INPUT DETECTED. PLEASE ENTER AN ANSWER",Toast.LENGTH_LONG);
                    toast.show();
                    editTextGuess1.requestFocus();
                }
                else if (editTextGuess1.getText().toString().toLowerCase().equals("jumpman") || editTextGuess1.getText().toString().toLowerCase().equals("jump man")){
                  score += 1000;

                    buttonSubmit.setEnabled(false);
                    editTextGuess1.setEnabled(false);
                    scoreTxt = String.valueOf(score);

                    Intent intent = new Intent(Question1Activity.this,Question2Activity.class);
                    intent.putExtra("SCORE",scoreTxt);

                    startActivity(intent);
                    finish();
                }
                else{
                    scoreTxt = String.valueOf(score);

                    Intent intent = new Intent(Question1Activity.this,Question2Activity.class);
                    intent.putExtra("SCORE",scoreTxt);

                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
