package edu.ranken.thomasperrier.videogametriviaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class Question3Activity extends AppCompatActivity {

    Button buttonSubmit;
    RadioButton radioButtonTrue;
    RadioButton radioButtonFalse;
    int score;
    String scoreTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question3);

        buttonSubmit = findViewById(R.id.buttonSubmit6);
        radioButtonTrue = findViewById(R.id.radioButtonTrue);
        radioButtonFalse = findViewById(R.id.radioButtonFalse);

        Intent intent = getIntent();
        scoreTxt = intent.getStringExtra("SCORE").toString();

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                score = Integer.valueOf(scoreTxt);
                if(radioButtonTrue.isChecked()){
                    score += 1000;
                }
                buttonSubmit.setEnabled(false);
                scoreTxt = String.valueOf(score);

                Intent intent = new Intent(Question3Activity.this,Question4Activity.class);
                intent.putExtra("SCORE",scoreTxt);

                startActivity(intent);
                finish();
            }
        });
    }
}
